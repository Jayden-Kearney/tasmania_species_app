# leaflet-control-geocoder-demo-webpack

This demo demonstrates the usage of leaflet-control-geocoder using the [webpack](https://webpack.js.org/) bundler.

1. `cd demo-webpack/`
2. `npm install`
3. `npm run build`
4. `xdg-open index.html` or open `index.html` in your browser
